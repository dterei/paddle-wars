package com.TeamJava.PaddleWars;



//Java Class Imports

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.applet.AudioClip;

//End of Java Class imports



/** 
 * This class creates a rounded rectangle, which acts as a paddle. It creates the paddle with its various properties, it also animates it, and moves it. This class is also responsible for creating and managing the various instances need of the intercept class.
 * 
 * @author David Terei
 * @see PaddleWars
 * @see intercept
 * @version 22/8/03
 */
public class paddle extends JPanel {


       /** 
        * An array of the intercept class. The arraylength is equal to the number of balls their are. This array manages the intercept class for each ball for this paddle.
        * 
        * @see intercept
        */
       private static intercept[] BallIntercept;
       /** 
        * An array of the intercept class. The arraylength is equal to the number of missile for each player their are. This array manages the intercept class for each missile for this paddle.
        * 
        * @see intercept
        */
       private static intercept[][] MissileIntercept;
       /** 
        * Stores which paddle this is, in terms of its array posistion in the PaddleWars paddles variable.
        * 
        * @see PaddleWars
        */
       private int WhichPaddle;

       /** 
        * Stores the top left location of the paddle.
        */
       private Point2D.Double paddle = new Point2D.Double();
       /** 
        * Stores the fixed size of the x and y size of the paddle.
        */
       private Point2D.Double size = new Point2D.Double();
       /** 
        * Stores the variable y size of the paddle.
        */
       private int pSizeY = 2;
       /** 
        * Stores the variable x size of the paddle.
        */
       private int pSizeX = 2;

       /** 
        * Stores the array of Images of the paddle, which form its animation.
        */
       private  Image[] PaddleImage = new Image[4];
       /** 
        * Stores which frame the paddle's image animation is up to, in terms of which picture in the PaddleImage array.
        */
       private int frame = 0;
       /** 
        * Stores how many times in the threads cycle, that a image in the animation cycle has been displayed. This is to slow down the animation.
        */
       private int cycle = 0;
       /** 
        * Stores for how long an image in the animation cycle for the paddle should be displayed.
        */
       private int animationTimer = 0;
       /** 
        * Stores the y size or height of the applet.
        */
       private int aHeight;
       /** 
        * Stores the length of the Ball array in the PaddleWars class.
        * 
        * @see PaddleWars
        */
       private int BallLength;
       /** 
        * Stores the length of the Missiles array in the PaddleWars class.
        * 
        * @see PaddleWars
        */
       private int MissileLength;
       /** 
        * Stores the current delay set of the gameThread in PaddleWars, or the current game Speed.
        * 
        * @see PaddleWars
        */
       private int Gspeed;
       /** The audio clip to play when a ball hits the paddle.
        */
       private AudioClip paddleHit;


       /** 
        * The constructor for the paddle class. Provides the variables needed to create a paddle of an size at any posistion.
        * 
        * @param paddleX The x posistion of the paddle.
	* @param paddleY The y posistion of the paddle.
	* @param pXsize The fixed x size of the paddle.
	* @param pYsize The fixed y size of the paddle.
	* @param image The images of the paddle, that will cycle through for the 
	*     paddles animation.
	* @param color The colour of the paddle.
	* @param screenY The height of the area in which the paddle will operate.
	* @param Gspeed The delay on the gameThread, or the Game Speed.
	* @param arrayN The array posistion of this paddle, in the Paddle array, 
	*     in the PaddleWars class.
	* @param paddleHit The sound clip to play if a ball hits the paddle.
        * @see PaddleWars
        */
       public paddle(int paddleX, int paddleY, int pXsize,
                    int pYsize, Image[][] image, int color,
                    int screenY,int Gspeed, int arrayN, AudioClip paddleHit) {

              paddle.x = paddleX;
              paddle.y = paddleY;
              size.x = pXsize;
              size.y = pYsize;

              for (int i = 0; i<4; i++) {
                    PaddleImage[i] = image[color][i];
              }

              aHeight = screenY;

              BallLength = Interface.paddleWars.Ball.length;

              BallIntercept = new intercept[BallLength];

              for (int i = 0; i<BallLength; i++) {
                  int ballType = Interface.paddleWars.Ball[i].getBallType();
                  BallIntercept[i] = new intercept(i,ballType);
              }

              this.paddleHit = paddleHit;

              MissileLength = Interface.paddleWars.Missiles[0].length;

              MissileIntercept = new intercept[2][MissileLength];

              for (int i = 0;i<MissileLength; i++) {
                  MissileIntercept[0][i] = new intercept(0,i,2);
                  MissileIntercept[1][i] = new intercept(1,i,2);
              }

              WhichPaddle = arrayN;

              animationTimer = (int)Math.round(100/Gspeed*0.6);

       }


       /** 
        * The standard painting method. Paints utilizing the 2D Graphics class. Paints the paddle. Also calls the instances of the intercept class, to test for an intercept with this paddle.
        * 
        * @param g The Graphics object used to paint with.
        */
       public void paint(Graphics g) {


              Graphics2D g2 = (Graphics2D) g;

              Color paddleColor = new Color(60,60,60);
              g2.setColor(paddleColor);
              g2.fillRoundRect((int)paddle.x,(int)paddle.y,(int)size.x*pSizeX,(int)size.y*pSizeY,(int)size.x*pSizeX,(int)size.x*pSizeX);
              g2.drawImage(PaddleImage[frame],(int)paddle.x,(int)paddle.y,(int)size.x*pSizeX,(int)size.y*pSizeY,this);

              animatePaddle();


              for (int i = 0; i<BallLength; i++) {

                  Point2D.Double ball = Interface.paddleWars.Ball[i].getBallCenter();
                  int ballR = Interface.paddleWars.Ball[i].getBallRadius();
                  int ballS = Interface.paddleWars.Ball[i].getBallSize();

                  BallIntercept[i].TestIntercept(paddle , size, pSizeY, pSizeX, ball, ballR, ballS, WhichPaddle, paddleHit);

              }


              for (int i = 0; i<MissileLength; i++) {

                  Point2D.Double Missiles1Center = Interface.paddleWars.Missiles[0][i].getBallCenter();
                  int Missiles1Radius = Interface.paddleWars.Missiles[0][i].getBallRadius();
                  int Missiles1Size = Interface.paddleWars.Missiles[0][i].getBallSize();

                  MissileIntercept[0][i].TestIntercept(paddle , size, pSizeY, pSizeX, Missiles1Center, Missiles1Radius, Missiles1Size, WhichPaddle, paddleHit);

                  Point2D.Double Missiles2Center = Interface.paddleWars.Missiles[1][i].getBallCenter();
                  int Missiles2Radius = Interface.paddleWars.Missiles[1][i].getBallRadius();
                  int Missiles2Size = Interface.paddleWars.Missiles[1][i].getBallSize();

                  MissileIntercept[1][i].TestIntercept(paddle , size, pSizeY, pSizeX, Missiles2Center, Missiles2Radius, Missiles2Size, WhichPaddle, paddleHit);

              }


       }

       /** 
        * This method animate the paddle. It does this by cycling through the Images that make up the animation, and that were passeed in through the constructor.
        */
       private void animatePaddle() {

              cycle++;
              if (cycle == animationTimer) {
                    cycle = 0;
                    if (frame == 3) { frame = -1;}
                    frame++;
                    //paddleHit.play();

              }

       }

       /** 
        * Moves the paddle along its y axis.
        * 
        * @param velocity The value by which to move the paddle down the screen.
        */
       public void move(int velocity) {

              paddle.y += velocity;

              if (paddle.y < 0) { paddle.y = 0; }
              if (paddle.y + (size.y*pSizeY) > aHeight) { paddle.y = (aHeight-(size.y*pSizeY)); }

       }

       /** 
        * Returns the value of the paddle's variable x size.
        * 
        * @return Paddle's variable x size.
        */
       public int getpSizeX() {

           return pSizeX;

       }

       /** 
        * Returns the value of the paddle's variable y size.
        * 
        * @return Paddle's variable y size.
        */
       public int getpSizeY() {

           return pSizeY;

       }

       /** 
        * Finds the x co-ordinates for where a missile should start, when fired by this paddle.
        * 
        * @param side Which side of the paddle the missile shoudl start, left or 
	*     right.
        * @return Co-ordinates for where a missile should start.
        * @see ball
        */
       public int getMissileFireSpotX(int side) {

           if (side == 1) {

               return (int)(paddle.x);

           } else {

               return (int)(paddle.x+(size.x*pSizeX));

           }

       }

       /** 
        * Finds the y co-ordinates for where a missile should start, when fired by this paddle.
        * 
        * @return y co-ordinates for where a missile should start, when fired by this
	*      paddle.
        * @see ball
        */
       public int getMissileFireSpotY() {

           return (int)(paddle.y+((size.y*pSizeY)/2));


       }

       /** 
        * Find the paddle's center.
        * 
        * @return Co-ordinates for the paddles center.
        */
       public Point2D.Double getPaddleCenter() {

              Point2D.Double paddleC = new Point2D.Double();

              paddleC.x = paddle.x + ((pSizeX*size.x)/2);
              paddleC.y = paddle.y + ((pSizeY*size.y)/2);

              return paddleC;

       }

       /** 
        * Is used to find the y co-ordinate of the very top of the paddle.
        * 
        * @return Y co-ordinate of the very top of the paddle.
        */
       public int getPaddleTop() {

           return (int)paddle.y;

       }

       /** 
        * Is used to find the y co-ordinate of the very bottom of the paddle.
        * 
        * @return Y co-ordinate of the very bottom of the paddle.
        */
       public int getPaddleBottom() {

           return (int)(paddle.y+(int)(size.y*pSizeY));

       }

       /** 
        * Increases the variable x size of the paddle.
        * 
        * @param amount The amount by which to increase the variable x size of the 
	*     paddle,
        */
       public void increasepSizeX(int amount) {

           pSizeX += amount;

       }

       /** 
        * Increases the variable y size of the paddle.
        * 
        * @param amount The amount by which to increase the variable y size of the 
	*     paddle,
        */
       public void increasepSizeY(int amount) {

           pSizeY += amount;

       }
}
