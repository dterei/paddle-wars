//
//  Interface.java
//  A simple Java Swing applet
//
/*
   Version 1.4 - Added an extra class to allow for use of painting and drawing
                 of buttons in the one applet. Re-arranged program dramatically
                 again. Another consolidation will need to take place.

   Version 1.3 - Cleaned up the source code.

   Version 1.2 - Changed JPanel to a JDesktopPane. This was used to allow
                a more compatible housing for the JInternalFrame.

   Version 1.1 - Coded everything Swing format. Compatability issues faced
               switching from AWT.
               - Incorporated a menu.
   Version 1.0
    Did everything
    - Added buttons and layout
*/




package com.TeamJava.PaddleWars;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.EventListener;
import java.net.*;


public  class Interface extends JApplet implements ActionListener,
                                                  InternalFrameListener {

    //The following statements define the new variables.
    public static PaddleWars paddleWars;

    public JFrame jFrame1;
    private int jFrameSizeX;
    private int jFrameSizeY;
    private static Container jFrame1content;
    public JDesktopPane backPanel;
    public JPanel jPanel2;
    public JPanel aboutPanel;
    public JButton newGame;
    public JButton options;
    public JButton about;
    public JButton help;
    public JButton SinglePlayer;
    public JButton MultiPlayer;
    public JButton Practice;
    public ImageIcon icon;
    public JMenu menu;
    public JMenu Hmenu;
    public JMenuBar menuBar;
    public JMenuItem menuNew;
    public JMenuItem menuOptions;
    public JMenuItem menuExit;
    public JMenuItem menuIcon;
    JInternalFrame optionsFrame;
    JInternalFrame newFrame;
    JTabbedPane OptTab;
    JLabel Ball;
    JLabel fireball;
    JLabel iceball;
    JLabel slimeball;
    JRadioButton Fire;
    JRadioButton Ice;
    public JSeparator menuSep;
    int desktopWidth = 800;
    int desktopHeight = 600;
    int optFrameWidth = 640;
    int optFrameHeight = 480;
    int newFrameWidth = 610;
    int newFrameHeight = 150;
    int gamemode = 0;
    static final String SHOW = "show";
    static final String NEW = "new";
    static final String CLEAR = "clear";

    //Sounds
    private AudioClip PaddleHit;
    private AudioClip WallHit;

    //Images
    private Image backGround;
    private Image[] fireBall = new Image[12];
    private Image[] lightningBall = new Image[4];
    private Image[][] PaddleImage = new Image[3][4];

    //Paddles
    private int Paddle1 = 0;
    private int Paddle2 = 2;



    //The following class is the features of the program
    //that are initiliased when the program starts.
    public void init() {

        //Get applet Width and Hieght
        //int aWidth = size().width;
        //int aHeight = size().height;

        //Defines new objects here.
        jFrame1 = new JFrame();
        jFrame1content = jFrame1.getContentPane();
        //jFrame1.addKeyListener(new MyAdapter());
        //optionsFrame = new JInternalFrame("About", true, true, true, true);
        newGame = new JButton("New Game");
        options = new JButton("Options");
        about = new JButton("About");
        help = new JButton("Help");

        //icon = new ImageIcon("FireBall.png");
        //JLabel test = new JLabel(icon);


        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screen = kit.getScreenSize();
        jFrameSizeX = 800;
        jFrameSizeY = 550;
        jFrame1.setBounds(0,75,jFrameSizeX,jFrameSizeY);
        jFrame1.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        loadSounds();
        loadImages();
        paddleWars = new PaddleWars(jFrameSizeX,jFrameSizeY,PaddleHit,WallHit,backGround,PaddleImage,fireBall,lightningBall, 2);

        //jFrame1.getContentPane().add(paddleWars);



        newGame.setBounds(350,200,100,30);
        newGame.setActionCommand(NEW);
        options.setBounds(350,250,100,30);
        options.setActionCommand(SHOW);
        about.setBounds(350,300,100,30);
        help.setBounds(350,350,100,30);


        getContentPane().add(newGame);
        getContentPane().add(options);
        getContentPane().add(about);
        getContentPane().add(help);
        //getContentPane().add(optionsFrame);
        getContentPane().setBackground(Color.black);
        getContentPane().setLayout(null);

        newGame.addActionListener(this);
        about.addActionListener(this);
        options.addActionListener(this);
        //optionsFrame.addInternalFrameListener(this);


        //setJavaLookAndFeel();
        Menu();
        menu = new JMenu("A Menu");
        menuBar = new JMenuBar();

    }


    public void loadSounds(){

        try {
            PaddleHit = getAudioClip(getCodeBase(), "Resources/Sounds/rub_bounce.wav");
            WallHit = getAudioClip(getCodeBase(), "Resources/Sounds/metal_bounce.wav");
        } catch (Exception e) {
            System.out.println("Error Loading Sounds: "+e);
            System.out.println("No Sounds shall be availible");
        }

    }


    public void loadImages() {
        try {
            backGround = getImage(getCodeBase(), "Resources/Pics/backGround.gif");
            for (int i = 0; i<12; i++) {
                fireBall[i] = getImage(getCodeBase(),"Resources/Pics/FireBall/fireBall-"+(i+1)+".gif");
                prepareImage(fireBall[i],this);
                //System.out.println(i);
            }
            for (int i = 0; i<4; i++) {
                lightningBall[i] = getImage(getCodeBase(),"Resources/Pics/lightningBall/lightning-"+(i+1)+".gif");
                prepareImage(lightningBall[i],this);
                //System.out.println(i);
            }
            for (int i = 0; i<4; i++) {
                PaddleImage[0][i] = getImage(getCodeBase(),"Resources/Pics/Paddles/paddle-0-"+(i+1)+".gif");
                PaddleImage[1][i] = getImage(getCodeBase(),"Resources/Pics/Paddles/paddle-1-"+(i+1)+".gif");
                PaddleImage[2][i] = getImage(getCodeBase(),"Resources/Pics/Paddles/paddle-2-"+(i+1)+".gif");
                prepareImage(PaddleImage[0][i],this);
                prepareImage(PaddleImage[1][i],this);
                prepareImage(PaddleImage[2][i],this);
                //System.out.println(i);
            }
        } catch (Exception e) {
            System.out.println("Error Loading Images: "+e);
            System.out.println("The Game Will Not Function With No Images");
            System.out.println("Game Stopped:Please Reload It");
        }
    }


        public void newWindow() {
         newFrame = new JInternalFrame("New",
                                            false,  //resizable
                                            true,  //closable
                                            false,  //maximizable
                                            false); //iconifiable
         SinglePlayer = new JButton("Single Player");
         MultiPlayer = new JButton("Multi-Player");
         Practice = new JButton("Practice");

         SinglePlayer.setBounds(50,50,150,30);
         MultiPlayer.setBounds(230,50,150,30);
         Practice.setBounds(410,50,150,30);

         newFrame.setDefaultCloseOperation(
                                WindowConstants.DISPOSE_ON_CLOSE);
         newFrame.getContentPane().setLayout(null);
         newFrame.setBackground(Color.black);
         newFrame.setBounds(desktopWidth/2 - newFrameWidth/2,
                               desktopHeight/2 - newFrameHeight/2,
                               newFrameWidth,
                               newFrameHeight);
         newFrame.getContentPane().add(SinglePlayer);
         newFrame.getContentPane().add(MultiPlayer);
         newFrame.getContentPane().add(Practice);

         SinglePlayer.addActionListener(this);
         MultiPlayer.addActionListener(this);
         Practice.addActionListener(this);

        }

        public void optionsWindow() {

        //fireball = new JLabel(new ImageIcon("FireBall2.png"));
        //iceball = new JLabel(new ImageIcon("IceBall2.png"));
        //slimeball = new JLabel(new ImageIcon("SlimeBall2.png"));
        OptTab = new JTabbedPane();
        Ball = new JLabel("Ball skin");
        Fire = new JRadioButton("Fire Ball");
        Ice = new JRadioButton("Ice Ball");
        jPanel2 = new JPanel();
        optionsFrame = new JInternalFrame("Options",
                                              true,  //resizable
                                              true,  //closable
                                              true,  //maximizable
                                              true); //iconifiable
        //The next statement is necessary to work around bug 4138031.
        optionsFrame.setDefaultCloseOperation(
                                WindowConstants.DISPOSE_ON_CLOSE);
        optionsFrame.setSize(300, 100);
        optionsFrame.setBackground(Color.black);
        optionsFrame.setBounds(desktopWidth/2 - optFrameWidth/2,
                               desktopHeight/2 - optFrameHeight/2,
                               optFrameWidth,
                               optFrameHeight);

        OptTab.addTab("Ball", jPanel2);
        OptTab.addTab("Paddle", Ice);
        OptTab.setBackground(Color.green);
        OptTab.setBounds(0,
                               0,
                               optFrameWidth,
                               optFrameHeight);
        Ball.setBounds(10,10,100,10);
        Ball.setForeground(Color.white);
        Fire.setBounds(50,250,100,30);
        Fire.setBackground(Color.black);
        Fire.setForeground(Color.white);
        //fireball.setBounds(10,50,175,175);
        //fireball.setBackground(Color.black);
        //Ice.setBounds(200,250,100,30);
        //Ice.setBackground(Color.black);
        //Ice.setForeground(Color.white);
        //optionsFrame.setDefaultCloseOperation(
                                //WindowConstants.HIDE_ON_CLOSE);
        jPanel2.setLayout(null);
        optionsFrame.getContentPane().setLayout(null);
        optionsFrame.getContentPane().add(OptTab);
        //jPanel2.add(fireball);
        //jPanel2.add(iceball);
        //jPanel2.add(slimeball);
        jPanel2.add(Fire);
        //optionsFrame.getContentPane().add(Ice);

        }







    public void Menu() {
        menuBar = new JMenuBar();
           menu = new JMenu("A Menu");
           Hmenu = new JMenu("Help");
           menuNew = new JMenuItem("New", KeyEvent.VK_N);
           menuNew.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_N, ActionEvent.CTRL_MASK));
           menuNew.setActionCommand(NEW);
           menu.setMnemonic(KeyEvent.VK_M);
           menuOptions = new JMenuItem("Options", KeyEvent.VK_O);
           menuOptions.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_O, ActionEvent.CTRL_MASK));
           menuSep = new JSeparator();
           menuExit = new JMenuItem("Exit", KeyEvent.VK_E);
           menuExit.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_F4, ActionEvent.ALT_MASK));
           menuIcon = new JMenuItem("Icon", new ImageIcon("middle.gif"));
           menuIcon.setMnemonic(KeyEvent.VK_I);

           //menu.getAccessibleContext().setAccessibleDescription(
           // "The only menu in this program that has menu items");



           //menu.setText("Menu");
           menuBar.add(menu);
           menuBar.add(Hmenu);
           menu.add(menuNew);
           menu.add(menuOptions);
           menu.add(menuIcon);
           menu.add(menuSep);
           menu.add(menuExit);
           setJMenuBar(menuBar);
           menuNew.addActionListener(this);
           menuOptions.addActionListener(this);
           menuExit.addActionListener(this);
           //Hmenu.setAlignmentX(Component.RIGHT_ALIGNMENT);
           /*menuBar.setForeground(Color.black);
           menuBar.setBackground(Color.black);
           menu.setBackground(Color.black);
           menu.setForeground(Color.white);
           menuNew.setBackground(Color.black);
           menuNew.setForeground(Color.white);
           menuOptions.setBackground(Color.black);
           menuOptions.setForeground(Color.white);
           menuIcon.setBackground(Color.black);
           menuIcon.setForeground(Color.white);
           menuExit.setBackground(Color.black);
           menuExit.setForeground(Color.white);
           menuSep.setBackground(Color.black);

            */
    }



    /*public void initComponents() {
        Container contentPane = getContentPane();

        //Sets the background color Aqua. (redValue,greenValue,blueValue)
        setBackground(Color.black);

        icon = new ImageIcon("freesmall.gif");
        backPanel = new JDesktopPane();



        newGame = new JButton("New Game");
        options = new JButton("Options");
        //about = new JButton("About");
        help = new JButton("Help");
        JLabel label = new JLabel(icon);
        newGame.setBounds((aWidth/2-50),200,100,30);
        options.setBounds(350,250,100,30);
        //about.setBounds(350,300,100,30);
        help.setBounds(350,350,100,30);



        backPanel.setLayout(null);
        backPanel.setBackground(Color.black);




        jPanel2.setBounds(50,50,100,100);
        jPanel2.setBackground(Color.red);

        newGame.setToolTipText("Launch game");
        options.setToolTipText("Set the options for the game");
        //about.setToolTipText("About our program");
        help.setToolTipText("Help for our program");

        backPanel.add(aboutFrame);
        backPanel.add(newGame);
        backPanel.add(options);
        //backPanel.add(about);
        backPanel.add(help);
        backPanel.add(jPanel2);



        aboutPanel.setVisible(true);

        //jPanel2.add(label);
        getContentPane().add(backPanel);
        validate();



        options.addActionListener(this);
        //about.addActionListener(this);
        help.addActionListener(this);
        menuNew.addActionListener(this);
        menuOptions.addActionListener(this);
        newGame.addActionListener(this);


    }
        */


    public void actionPerformed(ActionEvent event) {

        if(event.getSource() == SinglePlayer){

            //get rid of everything
            jFrame1content.removeAll();
            jFrame1.dispose();
            paddleWars.exitGame();
            paddleWars = null;

            //Start new slate in Single Player Mode
            paddleWars = new PaddleWars(jFrameSizeX,jFrameSizeY,
                                    PaddleHit,WallHit,backGround,
                                    PaddleImage,fireBall,lightningBall, 0);
            jFrame1content.add(paddleWars);
            jFrame1.setVisible(true);

            //Request keyboard focus for paddleWars & see if it gets it or not
            boolean getFocus = paddleWars.requestFocusInWindow();
            //test if focus wasnt recieved
            if (getFocus == false) {
                System.out.println("Error: Focus Not recieved");
                System.out.println("Window Closed");
                jFrame1.setVisible(false);
            }

            //Start the game
            paddleWars.start();

        }

        if(event.getSource() == MultiPlayer){

            //get rid of everything
            jFrame1content.removeAll();
            jFrame1.dispose();
            paddleWars.exitGame();
            paddleWars = null;

            //Start new slate in Multiplayer Mode
            paddleWars = new PaddleWars(jFrameSizeX,400,
                                    PaddleHit,WallHit,backGround,
                                    PaddleImage,fireBall,lightningBall, 1);
            jFrame1content.add(paddleWars);
            jFrame1.setVisible(true);

            //Request keyboard focus for paddleWars & see if it gets it or not
            boolean getFocus = paddleWars.requestFocusInWindow();
            //test if focus wasnt recieved
            if (getFocus == false) {
                System.out.println("Error: Focus Not recieved");
                System.out.println("Window Closed");
                jFrame1.setVisible(false);
            }

            //Start the game
            paddleWars.start();

        }

        if(event.getSource() == Practice){

            //get rid of everything
            jFrame1content.removeAll();
            jFrame1.dispose();
            paddleWars.exitGame();
            paddleWars = null;

            //Start new slate in Practice Mode
            paddleWars = new PaddleWars(300,jFrameSizeY,
                                    PaddleHit,WallHit,backGround,
                                    PaddleImage,fireBall,lightningBall, 2);
            jFrame1content.add(paddleWars);
            jFrame1.setVisible(true);

            //Request keyboard focus for paddleWars & see if it gets it or not
            boolean getFocus = paddleWars.requestFocusInWindow();
            //test if focus wasnt recieved
            if (getFocus == false) {
                System.out.println("Error: Focus Not recieved");
                System.out.println("Window Closed");
                jFrame1.setVisible(false);
            }

            //Start the game
            paddleWars.start();

        }


        if(event.getSource() == about){

            }

        if(event.getSource() == options || event.getSource() == menuOptions){

            }

        if(event.getSource() == help){

            }

        if(event.getSource() == menuExit) {


            }

        if (event.getActionCommand().equals(SHOW)) {
        if (optionsFrame == null) {
                optionsWindow();
                optionsFrame.addInternalFrameListener(this);
                getContentPane().add(optionsFrame);
                //optionsFrame.setLocation(
                    //desktopWidth/2 - optionsFrame.getWidth()/2,
                    //desktopHeight/2 - optionsFrame.getHeight());
                optionsFrame.setVisible(true);  //necessary as of 1.3
            }
            }
        if (event.getActionCommand().equals(NEW)) {
        if (newFrame == null) {
                newWindow();
                newFrame.addInternalFrameListener(this);
                getContentPane().add(newFrame);
                //optionsFrame.setLocation(
                    //desktopWidth/2 - optionsFrame.getWidth()/2,
                    //desktopHeight/2 - optionsFrame.getHeight());
                newFrame.setVisible(true);  //necessary as of 1.3
                }

            }
    }


    public void internalFrameOpened(InternalFrameEvent e) {
        //XXX: We don't seem to get any of these.
        //displayMessage("Internal frame opened", e);
            newGame.setVisible(false);
            options.setVisible(false);
            about.setVisible(false);
            help.setVisible(false);

             }

    public void internalFrameActivated(InternalFrameEvent e) {

            }

    public void internalFrameDeactivated(InternalFrameEvent e) {

            }

    public void internalFrameIconified(InternalFrameEvent e) {

            }

    public void internalFrameDeiconified(InternalFrameEvent e) {

            }

    public void internalFrameClosed(InternalFrameEvent e) {
           optionsFrame = null;
           newFrame = null;
           System.out.println("Frame Closed");

            }

    public void internalFrameClosing(InternalFrameEvent e)   {
            Buttons();
             }
        public void Buttons(){
            newGame.setVisible(true);
            options.setVisible(true);
            about.setVisible(true);
            help.setVisible(true);
            System.out.println("Hi");
        }





  /** Tell system to use native look and feel, as in previous
   *  releases. Metal (Java) LAF is the default otherwise.
   */

  public static void setNativeLookAndFeel() {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch(Exception e) {
      System.out.println("Error setting native LAF: " + e);
    }
  }

  public static void setJavaLookAndFeel() {
    try {
      UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
    } catch(Exception e) {
      System.out.println("Error setting Java LAF: " + e);
    }
  }

  public static void setMotifLookAndFeel() {
    try {
      UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
    } catch(Exception e) {
      System.out.println("Error setting Motif LAF: " + e);
    }
  }

  public static void setMetalBorders() {
    try {
      UIManager.setLookAndFeel("UIManager.com.sun.javax.swing.plaf.basic.BasicInternalFrameUI");
    } catch(Exception e) {
      System.out.println("Error setting Metal LAF: " + e);
    }
  }


  class MyAdapter extends KeyAdapter {

             /** Handle the key typed event from the text field. */
             public void keyTyped(KeyEvent e) {

                    System.out.println("KEY");

             }

             /** Handle the key pressed event from the text field. */
             public void keyPressed(KeyEvent e) {

                    System.out.println("KEY");

             }

             /** Handle the key released event from the text field. */
             public void keyReleased(KeyEvent e) {

                    System.out.println("KEY");

             }

       }

}


/*
class PaddleWars extends JPanel {

    int x;

    public PaddleWars(int gameMode) {

    }



    public void paint(Graphics g) {

        g.setColor(Color.black);
        g.fillRect(0,0,800,600);

        g.setColor(Color.yellow);
        g.fillRect(x,x,10,10);


        repaint();

        }

      public void setGameMode(int gameMode) {

            x = gameMode * 80;

      }

    }

    /*class InternalFrameEvent extends Object implements EventListener   {
      public void internalFrameClosing(InternalFrameEvent e)   {
              Buttons();
             }
        public void Buttons(){
            newGame.setVisible(true);
            options.setVisible(true);
            about.setVisible(true);
            help.setVisible(true);
        }
}  */