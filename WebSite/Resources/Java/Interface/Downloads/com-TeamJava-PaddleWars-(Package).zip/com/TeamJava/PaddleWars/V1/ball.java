package com.TeamJava.PaddleWars;



//Java Class Imports

import java.awt.*;
import java.awt.geom.*;
import java.applet.*;
import javax.swing.*;

//End of Java Class imports



public class ball extends JPanel {



      private Point2D.Double center = new Point2D.Double();
      private int r;

      private int xM = -2;
      private int yM = 0;

      private int Speed = 2;
      private int Size = 2;

      private int BallType;
      private int bounces =6;
      private int MissileExploded = 1;

      private int Delay = 75;

      private Image[] Ball;
      private int cycle = 0;
      private int frame = 0;

      private Color[] Color;
      private int BonusType;

      private AudioClip WallHit;

      public int aWidth;
      public int aHeight;

      private int arrayNumber;
      private int Player;



      public ball(int ballX,int ballY, int ballR, Image[] ball, int screenX, int screenY, AudioClip wallhit) {

             center.x = ballX;
             center.y = ballY;
             r = ballR;

             BallType = 0;

             aWidth = screenX;
             aHeight = screenY;

             Ball = new Image[ball.length];
             Ball = ball;

             WallHit = wallhit;

      }

      public ball(int ballX,int ballY, int ballR, Color[] color, int bonusType, int screenX, int screenY, AudioClip wallhit, int arrayN) {

             center.x = ballX;
             center.y = ballY;
             r = ballR;

             BallType = 1;

             aWidth = screenX;
             aHeight = screenY;

             Color = new Color[color.length];
             Color = color;

             BonusType = bonusType;

             WallHit = wallhit;

             arrayNumber = arrayN;

      }

      public ball(int ballX,int ballY, int ballR, Image[] ball, int screenX, int screenY, AudioClip wallhit, int ballNumber, int player) {

             center.x = ballX;
             center.y = ballY;
             r = ballR;

             BallType = 2;

             aWidth = screenX;
             aHeight = screenY;

             Ball = new Image[ball.length];
             Ball = ball;

             WallHit = wallhit;

             arrayNumber = ballNumber;
             Player = player;

      }



      public void paint(Graphics g) {

             Graphics2D g2 = (Graphics2D) g;
             if (BallType != 1) {
                    //g2.fillOval((int)(center.x-r+1),(int)(center.y-r+1),r*2*Size-1,r*2*Size-1);
                    g2.drawImage(Ball[frame],(int)(center.x-(r*Size)),(int)(center.y-(r*Size)),r*2*Size,r*2*Size,this);
                    animateBall();
             } else {
                    g2.setColor(Color[BonusType]);
                    g2.fillOval((int)(center.x-(r*Size)),(int)(center.y-(r*Size)),r*2*Size,r*2*Size);
             }

      }


      public Point2D.Double getBallCenter() {

             Point2D.Double RealCenter = new Point2D.Double();

             RealCenter.x = center.x;
             RealCenter.y = center.y;

             return RealCenter;

      }


      public int getBallRadius() {

             return r;

      }


      public int getBallSize() {

             return Size;

      }


      public int getBallType() {

          return BallType;

      }

      public int getBonusType() {

          return BonusType;

      }

      public int getSpeed() {

          return Speed;

      }

      public int getVelocity(int whichOne) {

          if (whichOne == 0) {
              return xM;
          } else {
              return yM;
          }

      }

      private void animateBall() {

             cycle++;
             if (cycle % 3 == 0) {
                    cycle = 0;
                    if (frame == (Ball.length-1)) { frame = -1;}
                    frame++;
             }

      }


      private void moveBall(){  //moves the ball

             center.x += (Speed*xM);
             center.y += (Speed*(yM/2));

             changeBallY();

             if (BallType == 0) {
                    restartRound();
             } else {
                    changeBallX();
             }
      }



      private void changeBallY(){

             if (center.y<=(r*Size)) {
                    center.y = (r*Size)+1;
                    yM = -yM;
                    WallHit.play();
             }

             if (center.y+(r*Size) >= aHeight) {
                    center.y = (aHeight-(r*Size)-1);
                    yM = -yM;
                    WallHit.play();
             }

      }



      private void changeBallX() {

             if (center.x <= 0 && center.x> -50) {
                    center.x = 1;
                    xM = -xM;
                    bounces--;
                    MissileExploded--;
                    if (BallType == 1 && bounces == 0) {Interface.paddleWars.setBonusRunning(false); }
                    if (BallType == 2 && MissileExploded == 0) { Interface.paddleWars.resetMissile(Player, arrayNumber); }
                    WallHit.play();
             }

             if (center.x+(r*2*Size) >= aWidth && center.x < aWidth+100) {
                    center.x = (aWidth-(r*2*Size)-1);
                    xM = -xM;
                    bounces--;
                    MissileExploded--;
                    if (BallType == 1 && bounces == 0) {Interface.paddleWars.setBonusRunning(false); }
                    if (BallType == 2 && MissileExploded == 0) { Interface.paddleWars.resetMissile(Player, arrayNumber); }
                    WallHit.play();
             }

      }

      public void resetMissile() {

          System.out.println("Run: " + Player+":"+arrayNumber);
          Interface.paddleWars.resetMissile(Player, arrayNumber);

      }

      public void setBall(int x, int y) {

             center.x = x;
             center.y = y;

      }

      public void setBallVelocityX(int x) {

             xM = xM * x;

      }

      public void setBallVelocityY(int y) {

             yM = y;

      }

      public void increaseSize(int amount) {

          Size += amount;

      }

      public void increaseSpeed(int amount) {

          Speed += amount;

      }

      private void restartRound(){

             if (center.x+(r*2*Size) <= 0) {
                    Interface.paddleWars.setScore(-1,1);
                    center.x = aWidth/2;
                    center.y = aHeight/2;
                    xM = 2;
                    yM = 0;
                    Delay = 75;

                    int WhichWay;
                    if (xM > 0) {
                        WhichWay = 0;
                    } else {
                        WhichWay = 1;
                    }
                    Interface.paddleWars.setpredictTime(WhichWay,5);
             }

             if (center.x+(r*2*Size) >= aWidth) {
                    Interface.paddleWars.setScore(1,-1);
                    center.x = aWidth/2;
                    center.y = aHeight/2;
                    xM = 2;
                    yM = 0;
                    Delay = 75;

                    int WhichWay;
                    if (xM > 0) {
                        WhichWay = 0;
                    } else {
                        WhichWay = 1;
                    }
                    Interface.paddleWars.setpredictTime(WhichWay,5);
             }

      }


      public void runner() {

             if ( Delay>0 && BallType != 2) {
                    Delay--;
             } else {
                    moveBall();
             }

      }



}